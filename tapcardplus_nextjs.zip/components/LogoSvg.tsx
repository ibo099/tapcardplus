export default function LogoSvg() {
  return (
    <img
      src="/logo-base.svg"
      alt="TapCard Plus"
      className="h-8 w-auto"
    />
  );
}
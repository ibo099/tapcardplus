export default function LogoSvgWhite() {
  return (
    <img
      src="/logo-white.svg"
      alt="TapCard Plus"
      className="h-8 w-auto"
    />
  );
}